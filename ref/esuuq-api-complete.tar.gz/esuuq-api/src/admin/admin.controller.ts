import { Controller, Get, Patch, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery } from '@nestjs/swagger';
import { AdminService } from './admin.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { User, UserRole } from '../database/entities/user.entity';
import { OrderStatus } from '../database/entities/order.entity';

@ApiTags('admin')
@ApiBearerAuth('access-token')
@UseGuards(JwtAuthGuard)
@Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
@Controller('admin')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Get('dashboard')
  @ApiOperation({ summary: 'Platform dashboard — users, orders, revenue, charts' })
  getDashboard() { return this.adminService.getDashboardStats(); }

  @Get('health')
  @ApiOperation({ summary: 'Platform health alerts — stuck orders, low stock, pending merchants' })
  getHealth() { return this.adminService.getPlatformHealth(); }

  @Get('orders')
  @ApiOperation({ summary: 'All orders with filters' })
  @ApiQuery({ name: 'status', enum: OrderStatus, required: false })
  @ApiQuery({ name: 'search', required: false })
  getOrders(
    @Query('page') page = 1, @Query('limit') limit = 20,
    @Query('status') status?: OrderStatus, @Query('search') search?: string,
  ) { return this.adminService.getOrders(+page, +limit, status, search); }

  @Get('revenue')
  @ApiOperation({ summary: 'Revenue report with merchant and category breakdown' })
  @ApiQuery({ name: 'period', enum: ['week','month','quarter','year'], required: false })
  getRevenue(@Query('period') period: any = 'month') {
    return this.adminService.getRevenueReport(period);
  }

  @Get('products/pending')
  @ApiOperation({ summary: 'Products awaiting review/approval' })
  getPendingProducts(@Query('page') page = 1, @Query('limit') limit = 20) {
    return this.adminService.getPendingProducts(+page, +limit);
  }
}

import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { User } from '../database/entities/user.entity';
import { Order, OrderStatus } from '../database/entities/order.entity';
import { Product } from '../database/entities/product.entity';

@Injectable()
export class AdminService {
  private readonly logger = new Logger(AdminService.name);

  constructor(
    @InjectRepository(User)    private readonly usersRepo: Repository<User>,
    @InjectRepository(Order)   private readonly ordersRepo: Repository<Order>,
    @InjectRepository(Product) private readonly productsRepo: Repository<Product>,
    private readonly dataSource: DataSource,
  ) {}

  // ── Dashboard Stats ───────────────────────────
  async getDashboardStats() {
    const [
      userStats, orderStats, revenueStats,
      categoryBreakdown, recentOrders,
      signupsTrend, revenueTrend,
    ] = await Promise.all([
      // User counts by role
      this.dataSource.query(`
        SELECT
          COUNT(*)::int                                        AS total,
          COUNT(*) FILTER (WHERE role = 'customer')::int       AS customers,
          COUNT(*) FILTER (WHERE role = 'merchant')::int       AS merchants,
          COUNT(*) FILTER (WHERE role = 'delivery_partner')::int AS drivers,
          COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '30 days')::int AS new_this_month
        FROM users WHERE deleted_at IS NULL AND is_active = true
      `),

      // Order counts by status
      this.dataSource.query(`
        SELECT
          COUNT(*)::int                                                   AS total,
          COUNT(*) FILTER (WHERE status = 'confirmed')::int              AS confirmed,
          COUNT(*) FILTER (WHERE status = 'in_transit')::int             AS in_transit,
          COUNT(*) FILTER (WHERE status = 'delivered')::int              AS delivered,
          COUNT(*) FILTER (WHERE status = 'cancelled')::int              AS cancelled,
          COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '24 hours')::int AS today
        FROM orders
      `),

      // Revenue aggregates
      this.dataSource.query(`
        SELECT
          COALESCE(SUM(total), 0)::numeric                                       AS gross_revenue,
          COALESCE(SUM(total) FILTER (WHERE created_at >= NOW() - INTERVAL '30 days'), 0)::numeric AS revenue_this_month,
          COALESCE(SUM(total) FILTER (WHERE created_at >= NOW() - INTERVAL '7 days'), 0)::numeric  AS revenue_this_week,
          COALESCE(SUM(total) FILTER (WHERE created_at >= NOW() - INTERVAL '24 hours'), 0)::numeric AS revenue_today,
          COALESCE(AVG(total), 0)::numeric                                       AS avg_order_value
        FROM orders WHERE status NOT IN ('cancelled', 'refunded', 'pending_payment')
      `),

      // Revenue by category (last 30 days)
      this.dataSource.query(`
        SELECT c.name AS category, SUM(oi.total_price)::numeric AS revenue
        FROM order_items oi
        JOIN products p ON p.id = oi.product_id
        JOIN categories c ON c.id = p.category_id
        JOIN orders o ON o.id = oi.order_id
        WHERE o.status NOT IN ('cancelled','refunded')
          AND o.created_at >= NOW() - INTERVAL '30 days'
        GROUP BY c.name ORDER BY revenue DESC LIMIT 8
      `),

      // 10 most recent orders
      this.ordersRepo.find({
        order: { createdAt: 'DESC' },
        take: 10,
        relations: ['customer'],
      }),

      // Daily signups last 14 days
      this.dataSource.query(`
        SELECT DATE(created_at) AS date, COUNT(*)::int AS count
        FROM users
        WHERE created_at >= NOW() - INTERVAL '14 days' AND deleted_at IS NULL
        GROUP BY DATE(created_at) ORDER BY date ASC
      `),

      // Daily revenue last 14 days
      this.dataSource.query(`
        SELECT DATE(created_at) AS date, COALESCE(SUM(total), 0)::numeric AS revenue
        FROM orders
        WHERE created_at >= NOW() - INTERVAL '14 days'
          AND status NOT IN ('cancelled','refunded','pending_payment')
        GROUP BY DATE(created_at) ORDER BY date ASC
      `),
    ]);

    return {
      users:     userStats[0],
      orders:    orderStats[0],
      revenue:   revenueStats[0],
      categoryBreakdown,
      recentOrders,
      charts: { signupsTrend, revenueTrend },
    };
  }

  // ── Orders management ─────────────────────────
  async getOrders(page = 1, limit = 20, status?: OrderStatus, search?: string) {
    const qb = this.ordersRepo
      .createQueryBuilder('o')
      .leftJoinAndSelect('o.customer', 'c')
      .leftJoinAndSelect('o.items', 'i')
      .orderBy('o.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit);

    if (status) qb.andWhere('o.status = :status', { status });
    if (search) qb.andWhere('o.id LIKE :s', { s: `%${search}%` });

    const [data, total] = await qb.getManyAndCount();
    return { data, meta: { total, page, limit, pages: Math.ceil(total / limit) } };
  }

  // ── Platform revenue report ───────────────────
  async getRevenueReport(period: 'week' | 'month' | 'quarter' | 'year' = 'month') {
    const intervals: Record<string, string> = {
      week: '7 days', month: '30 days', quarter: '90 days', year: '365 days',
    };

    const [totals, byMerchant, byCategory, refunds] = await Promise.all([
      this.dataSource.query(`
        SELECT
          SUM(o.total)::numeric                    AS gross_revenue,
          SUM(oi.commission)::numeric              AS platform_commission,
          SUM(oi.merchant_earnings)::numeric       AS merchant_payouts,
          COUNT(DISTINCT o.id)::int                AS orders,
          COUNT(DISTINCT o.customer_id)::int       AS unique_customers
        FROM orders o JOIN order_items oi ON oi.order_id = o.id
        WHERE o.status NOT IN ('cancelled','refunded','pending_payment')
          AND o.created_at >= NOW() - INTERVAL '${intervals[period]}'
      `),

      this.dataSource.query(`
        SELECT
          m.store_name, m.id AS merchant_id,
          SUM(oi.total_price)::numeric     AS revenue,
          SUM(oi.commission)::numeric      AS commission,
          COUNT(DISTINCT o.id)::int        AS orders
        FROM order_items oi
        JOIN merchants m ON m.id = oi.merchant_id
        JOIN orders o ON o.id = oi.order_id
        WHERE o.status NOT IN ('cancelled','refunded')
          AND o.created_at >= NOW() - INTERVAL '${intervals[period]}'
        GROUP BY m.id, m.store_name
        ORDER BY revenue DESC LIMIT 10
      `),

      this.dataSource.query(`
        SELECT c.name, SUM(oi.total_price)::numeric AS revenue
        FROM order_items oi
        JOIN products p ON p.id = oi.product_id
        JOIN categories c ON c.id = p.category_id
        JOIN orders o ON o.id = oi.order_id
        WHERE o.status NOT IN ('cancelled','refunded')
          AND o.created_at >= NOW() - INTERVAL '${intervals[period]}'
        GROUP BY c.name ORDER BY revenue DESC
      `),

      this.dataSource.query(`
        SELECT COUNT(*)::int AS count, COALESCE(SUM(total), 0)::numeric AS amount
        FROM orders
        WHERE status = 'refunded'
          AND updated_at >= NOW() - INTERVAL '${intervals[period]}'
      `),
    ]);

    return { period, totals: totals[0], byMerchant, byCategory, refunds: refunds[0] };
  }

  // ── Product moderation ────────────────────────
  async getPendingProducts(page = 1, limit = 20) {
    const [data, total] = await this.productsRepo.findAndCount({
      where: { status: 'pending_review' as any },
      relations: ['merchant', 'category'],
      order: { createdAt: 'ASC' },
      skip: (page - 1) * limit,
      take: limit,
    });
    return { data, meta: { total, page, limit } };
  }

  // ── Platform health ───────────────────────────
  async getPlatformHealth() {
    const [stuckOrders, lowStockProducts, pendingMerchants] = await Promise.all([
      // Orders stuck in processing > 24h
      this.dataSource.query(`
        SELECT COUNT(*)::int AS count FROM orders
        WHERE status IN ('confirmed','processing')
          AND updated_at < NOW() - INTERVAL '24 hours'
      `),
      // Products with critically low stock (< 5)
      this.dataSource.query(`
        SELECT COUNT(*)::int AS count FROM products
        WHERE stock < 5 AND stock > 0 AND status = 'active' AND deleted_at IS NULL
      `),
      // Merchants awaiting approval
      this.dataSource.query(`
        SELECT COUNT(*)::int AS count FROM merchants WHERE status = 'pending'
      `),
    ]);

    return {
      alerts: {
        stuckOrders:       stuckOrders[0].count,
        lowStockProducts:  lowStockProducts[0].count,
        pendingMerchants:  pendingMerchants[0].count,
      },
      healthy: Object.values({
        stuckOrders: stuckOrders[0].count,
        lowStockProducts: lowStockProducts[0].count,
        pendingMerchants: pendingMerchants[0].count,
      }).every((v) => v === 0),
    };
  }
}

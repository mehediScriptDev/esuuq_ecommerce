import {
  Controller, Get, Post, Put, Patch, Body, Param,
  Query, UseGuards, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery } from '@nestjs/swagger';
import { IsString, IsOptional, IsNumber, Min, Max } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { MerchantsService } from './merchants.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Public } from '../common/decorators/public.decorator';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { Roles } from '../common/decorators/roles.decorator';
import { User, UserRole } from '../database/entities/user.entity';
import { MerchantStatus } from '../database/entities/supporting.entities';

class RegisterMerchantDto {
  @ApiProperty({ example: 'Aisha Electronics' }) @IsString() storeName: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional() @IsOptional() businessInfo?: any;
}

class UpdateStoreDto {
  @ApiPropertyOptional() @IsOptional() @IsString() storeName?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() logoUrl?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() bannerUrl?: string;
  @ApiPropertyOptional() @IsOptional() businessInfo?: any;
  @ApiPropertyOptional() @IsOptional() @IsNumber() returnPolicyDays?: number;
}

class PayoutRequestDto {
  @ApiProperty({ example: 150.00 }) @IsNumber() @Min(20) amount: number;
}

@ApiTags('merchants')
@ApiBearerAuth('access-token')
@UseGuards(JwtAuthGuard)
@Controller('merchants')
export class MerchantsController {
  constructor(private readonly merchantsService: MerchantsService) {}

  // ── Public ─────────────────────────────────────
  @Public()
  @Get('store/:slug')
  @ApiOperation({ summary: 'Get merchant store by slug (public)' })
  findBySlug(@Param('slug') slug: string) { return this.merchantsService.findBySlug(slug); }

  // ── Merchant-facing ────────────────────────────
  @Post('register')
  @ApiOperation({ summary: 'Register a new merchant store' })
  register(@CurrentUser() user: User, @Body() dto: RegisterMerchantDto) {
    return this.merchantsService.register(user.id, dto);
  }

  @Get('me')
  @ApiOperation({ summary: "Get own merchant store" })
  getMyStore(@CurrentUser() user: User) { return this.merchantsService.findByUserId(user.id); }

  @Put('me')
  @ApiOperation({ summary: 'Update store profile' })
  updateStore(@CurrentUser() user: User, @Body() dto: UpdateStoreDto) {
    // merchantId resolved from user in service
    return this.merchantsService.findByUserId(user.id).then((m) => {
      if (!m) throw new Error('No merchant store found');
      return this.merchantsService.updateStore(m.id, user.id, dto);
    });
  }

  @Patch('me/toggle-online')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Toggle store online / offline status' })
  toggleOnline(@CurrentUser() user: User) {
    return this.merchantsService.findByUserId(user.id).then((m) => {
      if (!m) throw new Error('No merchant store found');
      return this.merchantsService.toggleOnline(m.id, user.id);
    });
  }

  @Get('me/earnings')
  @ApiOperation({ summary: 'Get earnings dashboard' })
  @ApiQuery({ name: 'period', enum: ['week','month','year'], required: false })
  getEarnings(@CurrentUser() user: User, @Query('period') period: any = 'month') {
    return this.merchantsService.findByUserId(user.id).then((m) => {
      if (!m) throw new Error('No merchant store found');
      return this.merchantsService.getEarnings(m.id, period);
    });
  }

  @Post('me/payout')
  @ApiOperation({ summary: 'Request a payout to connected bank account' })
  requestPayout(@CurrentUser() user: User, @Body() dto: PayoutRequestDto) {
    return this.merchantsService.findByUserId(user.id).then((m) => {
      if (!m) throw new Error('No merchant store found');
      return this.merchantsService.requestPayout(m.id, user.id, dto.amount);
    });
  }

  // ── Admin ──────────────────────────────────────
  @Get()
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Admin: list all merchants' })
  @ApiQuery({ name: 'status', enum: MerchantStatus, required: false })
  findAll(@Query('page') page = 1, @Query('limit') limit = 20, @Query('status') status?: MerchantStatus) {
    return this.merchantsService.findAll(+page, +limit, status);
  }

  @Get(':id')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Admin: get merchant by ID' })
  findOne(@Param('id') id: string) { return this.merchantsService.findById(id); }

  @Patch(':id/approve')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Admin: approve a merchant' })
  approve(@Param('id') id: string, @Body() body: { commissionRate?: number }) {
    return this.merchantsService.approve(id, body.commissionRate);
  }

  @Patch(':id/suspend')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Admin: suspend a merchant' })
  suspend(@Param('id') id: string, @Body() body: { reason?: string }) {
    return this.merchantsService.suspend(id, body.reason);
  }

  @Patch(':id/commission')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Admin: set merchant commission rate' })
  setCommission(@Param('id') id: string, @Body() body: { rate: number }) {
    return this.merchantsService.setCommissionRate(id, body.rate);
  }
}

import {
  Injectable, NotFoundException, ConflictException,
  BadRequestException, ForbiddenException, Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import slugify from 'slugify';
import { ulid } from 'ulid';
import { Merchant, MerchantStatus } from '../database/entities/supporting.entities';
import { User, UserRole } from '../database/entities/user.entity';
import { Order, OrderItem } from '../database/entities/order.entity';

@Injectable()
export class MerchantsService {
  private readonly logger = new Logger(MerchantsService.name);

  constructor(
    @InjectRepository(Merchant) private readonly repo: Repository<Merchant>,
    @InjectRepository(OrderItem) private readonly itemsRepo: Repository<OrderItem>,
    private readonly dataSource: DataSource,
  ) {}

  // ── Register store ────────────────────────────
  async register(userId: string, dto: {
    storeName: string; description?: string; businessInfo?: any;
  }): Promise<Merchant> {
    const existing = await this.repo.findOne({ where: { userId } });
    if (existing) throw new ConflictException('You already have a merchant store');

    const slug = await this.generateSlug(dto.storeName);
    const merchant = this.repo.create({
      id: ulid(),
      userId,
      storeName: dto.storeName,
      storeSlug: slug,
      description: dto.description,
      businessInfo: dto.businessInfo,
      status: MerchantStatus.PENDING,
      commissionRate: 8.0,
    });
    const saved = await this.repo.save(merchant);
    this.logger.log(`Merchant registered: ${saved.id} (${saved.storeName})`);
    return saved;
  }

  // ── Get own store ─────────────────────────────
  async findByUserId(userId: string): Promise<Merchant | null> {
    return this.repo.findOne({ where: { userId } });
  }

  async findById(id: string): Promise<Merchant> {
    const m = await this.repo.findOne({ where: { id }, relations: ['user'] });
    if (!m) throw new NotFoundException(`Merchant ${id} not found`);
    return m;
  }

  async findBySlug(slug: string): Promise<Merchant> {
    const m = await this.repo.findOne({ where: { storeSlug: slug } });
    if (!m) throw new NotFoundException(`Store "${slug}" not found`);
    return m;
  }

  // ── Update store profile ──────────────────────
  async updateStore(merchantId: string, userId: string, dto: {
    storeName?: string; description?: string;
    logoUrl?: string; bannerUrl?: string;
    businessInfo?: any; returnPolicyDays?: number; isOnline?: boolean;
  }): Promise<Merchant> {
    const merchant = await this.findById(merchantId);
    if (merchant.userId !== userId) throw new ForbiddenException();

    if (dto.storeName && dto.storeName !== merchant.storeName) {
      dto['storeSlug'] = await this.generateSlug(dto.storeName, merchantId);
    }
    return this.repo.save(Object.assign(merchant, dto));
  }

  async toggleOnline(merchantId: string, userId: string): Promise<{ isOnline: boolean }> {
    const merchant = await this.findById(merchantId);
    if (merchant.userId !== userId) throw new ForbiddenException();
    const isOnline = !merchant.isOnline;
    await this.repo.update(merchantId, { isOnline });
    return { isOnline };
  }

  // ── Earnings dashboard ────────────────────────
  async getEarnings(merchantId: string, period: 'week' | 'month' | 'year' = 'month') {
    const intervals: Record<string, string> = {
      week:  '7 days',
      month: '30 days',
      year:  '365 days',
    };

    const [summary, dailyBreakdown, topProducts] = await Promise.all([
      // Totals for period
      this.dataSource.query(`
        SELECT
          COALESCE(SUM(oi.total_price), 0)::numeric        AS gross_revenue,
          COALESCE(SUM(oi.commission), 0)::numeric         AS total_commission,
          COALESCE(SUM(oi.merchant_earnings), 0)::numeric  AS net_earnings,
          COUNT(DISTINCT o.id)::int                        AS order_count,
          COUNT(oi.id)::int                                AS item_count
        FROM order_items oi
        JOIN orders o ON o.id = oi.order_id
        WHERE oi.merchant_id = $1
          AND o.status NOT IN ('cancelled','refunded','return_requested','returned')
          AND o.created_at >= NOW() - INTERVAL '${intervals[period]}'
      `, [merchantId]),

      // Daily revenue breakdown
      this.dataSource.query(`
        SELECT
          DATE(o.created_at)                              AS date,
          COALESCE(SUM(oi.merchant_earnings), 0)::numeric AS earnings,
          COUNT(DISTINCT o.id)::int                       AS orders
        FROM order_items oi
        JOIN orders o ON o.id = oi.order_id
        WHERE oi.merchant_id = $1
          AND o.status NOT IN ('cancelled','refunded')
          AND o.created_at >= NOW() - INTERVAL '${intervals[period]}'
        GROUP BY DATE(o.created_at)
        ORDER BY date ASC
      `, [merchantId]),

      // Top 5 products by revenue
      this.dataSource.query(`
        SELECT
          oi.product_id,
          oi.product_name,
          oi.product_image,
          SUM(oi.quantity)::int                          AS units_sold,
          SUM(oi.total_price)::numeric                   AS gross_revenue,
          SUM(oi.merchant_earnings)::numeric             AS net_earnings
        FROM order_items oi
        JOIN orders o ON o.id = oi.order_id
        WHERE oi.merchant_id = $1
          AND o.status NOT IN ('cancelled','refunded')
          AND o.created_at >= NOW() - INTERVAL '${intervals[period]}'
        GROUP BY oi.product_id, oi.product_name, oi.product_image
        ORDER BY gross_revenue DESC
        LIMIT 5
      `, [merchantId]),
    ]);

    const merchant = await this.repo.findOneBy({ id: merchantId });

    return {
      period,
      summary: {
        ...summary[0],
        availableBalance: merchant?.availableBalance ?? 0,
      },
      dailyBreakdown,
      topProducts,
    };
  }

  // ── Payout request ────────────────────────────
  async requestPayout(merchantId: string, userId: string, amount: number) {
    const merchant = await this.findById(merchantId);
    if (merchant.userId !== userId) throw new ForbiddenException();
    if (!merchant.stripeAccountId) {
      throw new BadRequestException('Please connect your bank account before requesting a payout');
    }
    const minPayout = 20;
    if (amount < minPayout) throw new BadRequestException(`Minimum payout is $${minPayout}`);
    if (amount > Number(merchant.availableBalance)) {
      throw new BadRequestException('Insufficient balance for this payout amount');
    }

    // Deduct from balance optimistically; PaymentsService completes the transfer
    await this.repo.decrement({ id: merchantId }, 'availableBalance', amount);
    this.logger.log(`Payout requested: $${amount} from merchant ${merchantId}`);
    return { requested: true, amount, remainingBalance: Number(merchant.availableBalance) - amount };
  }

  // ── Credit merchant earnings (called post-delivery) ──
  async creditEarnings(merchantId: string, amount: number): Promise<void> {
    await this.repo.increment({ id: merchantId }, 'availableBalance', amount);
    await this.repo.increment({ id: merchantId }, 'totalRevenue', amount);
  }

  // ── Admin operations ──────────────────────────
  async findAll(page = 1, limit = 20, status?: MerchantStatus) {
    const where: any = {};
    if (status) where.status = status;
    const [data, total] = await this.repo.findAndCount({
      where,
      relations: ['user'],
      order: { createdAt: 'DESC' },
      skip: (page - 1) * limit,
      take: limit,
    });
    return { data, meta: { total, page, limit, pages: Math.ceil(total / limit) } };
  }

  async approve(id: string, commissionRate?: number): Promise<Merchant> {
    const merchant = await this.findById(id);
    if (merchant.status === MerchantStatus.APPROVED) {
      throw new BadRequestException('Merchant is already approved');
    }
    const updates: Partial<Merchant> = { status: MerchantStatus.APPROVED };
    if (commissionRate !== undefined) updates.commissionRate = commissionRate;
    await this.repo.update(id, updates);
    this.logger.log(`Merchant approved: ${id}`);
    return this.findById(id);
  }

  async suspend(id: string, reason?: string): Promise<Merchant> {
    await this.repo.update(id, { status: MerchantStatus.SUSPENDED });
    this.logger.warn(`Merchant suspended: ${id} — ${reason ?? 'no reason given'}`);
    return this.findById(id);
  }

  async setCommissionRate(id: string, rate: number): Promise<Merchant> {
    if (rate < 0 || rate > 50) throw new BadRequestException('Commission rate must be 0–50%');
    await this.repo.update(id, { commissionRate: rate });
    return this.findById(id);
  }

  // ── Private helpers ───────────────────────────
  private async generateSlug(name: string, excludeId?: string): Promise<string> {
    let base = slugify(name, { lower: true, strict: true });
    let slug = base;
    let n = 1;
    while (true) {
      const existing = await this.repo.findOne({ where: { storeSlug: slug } });
      if (!existing || existing.id === excludeId) break;
      slug = `${base}-${n++}`;
    }
    return slug;
  }
}

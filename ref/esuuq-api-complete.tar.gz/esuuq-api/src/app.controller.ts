import { Controller, Get } from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';

@ApiTags('health')
@Controller()
export class AppController {
  @Get('health')
  @ApiOperation({ summary: 'Health check — returns API status' })
  health() {
    return {
      status: 'ok',
      service: 'esuuq-api',
      version: '1.0.0',
      timestamp: new Date().toISOString(),
    };
  }
}

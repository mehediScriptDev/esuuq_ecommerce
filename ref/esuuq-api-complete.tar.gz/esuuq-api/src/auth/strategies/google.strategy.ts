export { GoogleStrategy } from './local.strategy';

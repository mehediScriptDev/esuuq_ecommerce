import {
  Injectable, UnauthorizedException, ConflictException,
  BadRequestException, NotFoundException, Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Inject } from '@nestjs/common';
import { Cache } from 'cache-manager';
import * as bcrypt from 'bcrypt';
import { ulid } from 'ulid';

import { User, UserRole, AuthProvider } from '../database/entities/user.entity';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { VerifyOtpDto } from './dto/verify-otp.dto';
import { NotificationsService } from '../notifications/notifications.service';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);
  private readonly BCRYPT_ROUNDS = 12;
  private readonly OTP_PREFIX = 'otp:';
  private readonly BLACKLIST_PREFIX = 'blacklist:refresh:';

  constructor(
    @InjectRepository(User)
    private readonly usersRepo: Repository<User>,

    private readonly jwtService: JwtService,
    private readonly config: ConfigService,
    private readonly notifications: NotificationsService,

    @Inject(CACHE_MANAGER)
    private readonly cache: Cache,
  ) {}

  // ── Register ──────────────────────────────────
  async register(dto: RegisterDto) {
    const existing = await this.usersRepo.findOne({
      where: [{ email: dto.email }, { phone: dto.phone }],
    });
    if (existing) {
      throw new ConflictException(
        existing.email === dto.email
          ? 'Email already registered'
          : 'Phone number already registered',
      );
    }

    const passwordHash = await bcrypt.hash(dto.password, this.BCRYPT_ROUNDS);

    const user = this.usersRepo.create({
      firstName: dto.firstName,
      lastName: dto.lastName,
      email: dto.email,
      phone: dto.phone,
      passwordHash,
      role: (dto.role as UserRole) ?? UserRole.CUSTOMER,
      provider: AuthProvider.LOCAL,
      isVerified: false,
    });

    await this.usersRepo.save(user);

    // Generate and send OTP
    await this.sendOtp(user.id, user.email, user.phone);

    this.logger.log(`New user registered: ${user.email} [${user.role}]`);
    return { message: 'OTP sent to email and phone', userId: user.id };
  }

  // ── Validate local credentials ────────────────
  async validateUser(email: string, password: string): Promise<User> {
    const user = await this.usersRepo.findOne({
      where: { email },
      select: ['id', 'email', 'passwordHash', 'role', 'isVerified', 'isActive', 'firstName', 'lastName'],
    });

    if (!user || !user.passwordHash) {
      throw new UnauthorizedException('Invalid credentials');
    }
    if (!user.isActive) {
      throw new UnauthorizedException('Account deactivated');
    }

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) throw new UnauthorizedException('Invalid credentials');

    return user;
  }

  // ── Login ─────────────────────────────────────
  async login(user: User) {
    if (!user.isVerified) {
      // Resend OTP and ask them to verify
      await this.sendOtp(user.id, user.email, user.phone);
      throw new UnauthorizedException('Account not verified. New OTP sent.');
    }

    const tokens = await this.generateTokens(user);

    // Store hashed refresh token
    const refreshHash = await bcrypt.hash(tokens.refreshToken, 10);
    await this.usersRepo.update(user.id, {
      refreshTokenHash: refreshHash,
      lastLoginAt: new Date(),
    });

    return {
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
      user: this.sanitizeUser(user),
    };
  }

  // ── Verify OTP ────────────────────────────────
  async verifyOtp(dto: VerifyOtpDto) {
    const key = `${this.OTP_PREFIX}${dto.userId}`;
    const storedOtp = await this.cache.get<string>(key);

    if (!storedOtp) throw new BadRequestException('OTP expired or not found');

    const valid = await bcrypt.compare(dto.otp, storedOtp);
    if (!valid) throw new BadRequestException('Invalid OTP');

    // Mark verified and delete OTP
    await this.usersRepo.update(dto.userId, { isVerified: true });
    await this.cache.del(key);

    const user = await this.usersRepo.findOneByOrFail({ id: dto.userId });
    const tokens = await this.generateTokens(user);

    const refreshHash = await bcrypt.hash(tokens.refreshToken, 10);
    await this.usersRepo.update(user.id, {
      refreshTokenHash: refreshHash,
      lastLoginAt: new Date(),
    });

    this.logger.log(`User verified: ${user.email}`);
    return { ...tokens, verified: true, user: this.sanitizeUser(user) };
  }

  // ── Resend OTP ────────────────────────────────
  async resendOtp(userId: string) {
    const user = await this.usersRepo.findOneByOrFail({ id: userId });
    if (user.isVerified) throw new BadRequestException('Already verified');
    await this.sendOtp(user.id, user.email, user.phone);
    return { message: 'OTP resent' };
  }

  // ── Refresh Token ─────────────────────────────
  async refreshTokens(userId: string, refreshToken: string) {
    const user = await this.usersRepo.findOne({
      where: { id: userId },
      select: ['id', 'email', 'role', 'refreshTokenHash', 'isActive'],
    });

    if (!user?.refreshTokenHash || !user.isActive) {
      throw new UnauthorizedException('Access denied');
    }

    // Check blacklist
    const isBlacklisted = await this.cache.get(`${this.BLACKLIST_PREFIX}${refreshToken}`);
    if (isBlacklisted) throw new UnauthorizedException('Token revoked');

    const valid = await bcrypt.compare(refreshToken, user.refreshTokenHash);
    if (!valid) throw new UnauthorizedException('Invalid refresh token');

    const tokens = await this.generateTokens(user);
    const newRefreshHash = await bcrypt.hash(tokens.refreshToken, 10);
    await this.usersRepo.update(userId, { refreshTokenHash: newRefreshHash });

    return { accessToken: tokens.accessToken, refreshToken: tokens.refreshToken };
  }

  // ── Logout ────────────────────────────────────
  async logout(userId: string, refreshToken?: string) {
    // Blacklist refresh token in Redis (TTL = refresh token expiry)
    if (refreshToken) {
      const ttl = 7 * 24 * 60 * 60 * 1000; // 7 days in ms
      await this.cache.set(`${this.BLACKLIST_PREFIX}${refreshToken}`, '1', ttl);
    }
    await this.usersRepo.update(userId, { refreshTokenHash: undefined });
    return { message: 'Logged out successfully' };
  }

  // ── Google OAuth ──────────────────────────────
  async googleLogin(profile: {
    id: string; email: string; firstName: string;
    lastName: string; avatarUrl?: string;
  }) {
    let user = await this.usersRepo.findOne({
      where: [{ email: profile.email }, { providerId: profile.id }],
    });

    if (!user) {
      user = this.usersRepo.create({
        ...profile,
        provider: AuthProvider.GOOGLE,
        providerId: profile.id,
        role: UserRole.CUSTOMER,
        isVerified: true,
        isActive: true,
      });
      await this.usersRepo.save(user);
      this.logger.log(`Google OAuth new user: ${user.email}`);
    }

    return this.login(user);
  }

  // ── Private Helpers ───────────────────────────
  private async generateTokens(user: User) {
    const payload = { sub: user.id, email: user.email, role: user.role };

    const [accessToken, refreshToken] = await Promise.all([
      this.jwtService.signAsync(payload, {
        secret: this.config.get('JWT_SECRET'),
        expiresIn: this.config.get('JWT_EXPIRES_IN', '15m'),
      }),
      this.jwtService.signAsync(payload, {
        secret: this.config.get('JWT_REFRESH_SECRET'),
        expiresIn: this.config.get('JWT_REFRESH_EXPIRES_IN', '7d'),
      }),
    ]);

    return { accessToken, refreshToken };
  }

  private async sendOtp(userId: string, email: string, phone?: string) {
    const otp = this.generateOtp();
    const otpHash = await bcrypt.hash(otp, 10);
    const ttl = this.config.get<number>('OTP_TTL_SECONDS', 600) * 1000;

    await this.cache.set(`${this.OTP_PREFIX}${userId}`, otpHash, ttl);

    // Send via email + SMS in parallel
    await Promise.allSettled([
      this.notifications.sendOtpEmail(email, otp),
      phone ? this.notifications.sendOtpSms(phone, otp) : Promise.resolve(),
    ]);
  }

  private generateOtp(): string {
    const len = this.config.get<number>('OTP_LENGTH', 6);
    return Math.floor(Math.random() * Math.pow(10, len))
      .toString()
      .padStart(len, '0');
  }

  private sanitizeUser(user: User) {
    const { passwordHash, refreshTokenHash, ...safe } = user as any;
    return safe;
  }
}

// ─── DTOs ────────────────────────────────────────────────────────────────────
// dto/register.dto.ts
import { IsEmail, IsString, MinLength, MaxLength, IsOptional, IsEnum, Matches } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class RegisterDto {
  @ApiProperty({ example: 'Ahmed' })
  @IsString() @MaxLength(80)
  firstName: string;

  @ApiProperty({ example: 'Mohamed' })
  @IsString() @MaxLength(80)
  lastName: string;

  @ApiProperty({ example: 'ahmed@email.com' })
  @IsEmail()
  email: string;

  @ApiPropertyOptional({ example: '+16125550198' })
  @IsOptional()
  @Matches(/^\+[1-9]\d{6,14}$/, { message: 'Phone must be in E.164 format' })
  phone?: string;

  @ApiProperty({ example: 'SecurePass123!', minLength: 8 })
  @IsString() @MinLength(8) @MaxLength(72)
  password: string;

  @ApiPropertyOptional({ enum: ['customer', 'merchant', 'delivery_partner'] })
  @IsOptional() @IsEnum(['customer', 'merchant', 'delivery_partner'])
  role?: string;
}

// dto/login.dto.ts
export class LoginDto {
  @ApiProperty({ example: 'ahmed@email.com' })
  @IsEmail()
  email: string;

  @ApiProperty({ example: 'SecurePass123!' })
  @IsString() @MinLength(1)
  password: string;
}

// dto/verify-otp.dto.ts
export class VerifyOtpDto {
  @ApiProperty({ example: 'usr_01HZ4K...' })
  @IsString()
  userId: string;

  @ApiProperty({ example: '842791' })
  @IsString() @MinLength(6) @MaxLength(6)
  otp: string;
}

// dto/refresh-token.dto.ts
export class RefreshTokenDto {
  @ApiPropertyOptional({ description: 'Refresh token (or read from httpOnly cookie)' })
  @IsOptional() @IsString()
  refreshToken?: string;
}

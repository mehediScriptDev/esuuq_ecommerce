import {
  Injectable, BadRequestException, Logger,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Stripe from 'stripe';

@Injectable()
export class PaymentsService {
  private readonly stripe: Stripe;
  private readonly logger = new Logger(PaymentsService.name);

  constructor(private readonly config: ConfigService) {
    this.stripe = new Stripe(config.get<string>('STRIPE_SECRET_KEY'), {
      apiVersion: '2023-10-16',
    });
  }

  // ── Create PaymentIntent ──────────────────────
  async createPaymentIntent(
    amount: number,       // in cents
    currency = 'usd',
    metadata: Record<string, string> = {},
  ) {
    const intent = await this.stripe.paymentIntents.create({
      amount: Math.round(amount * 100), // dollars → cents
      currency,
      automatic_payment_methods: { enabled: true },
      metadata,
    });

    return {
      clientSecret: intent.client_secret,
      intentId: intent.id,
    };
  }

  // ── Confirm Payment (webhook) ─────────────────
  async handleWebhook(payload: Buffer, signature: string) {
    const secret = this.config.get<string>('STRIPE_WEBHOOK_SECRET');
    let event: Stripe.Event;

    try {
      event = this.stripe.webhooks.constructEvent(payload, signature, secret);
    } catch (err) {
      throw new BadRequestException(`Webhook signature invalid: ${err.message}`);
    }

    switch (event.type) {
      case 'payment_intent.succeeded':
        await this.onPaymentSucceeded(event.data.object as Stripe.PaymentIntent);
        break;
      case 'payment_intent.payment_failed':
        await this.onPaymentFailed(event.data.object as Stripe.PaymentIntent);
        break;
      case 'transfer.created':
        this.logger.log(`Payout transfer created: ${(event.data.object as any).id}`);
        break;
    }

    return { received: true };
  }

  // ── Merchant Payout ───────────────────────────
  async createPayout(merchantStripeAccountId: string, amountDollars: number) {
    const minPayout = this.config.get<number>('MIN_PAYOUT_AMOUNT', 20);
    if (amountDollars < minPayout) {
      throw new BadRequestException(`Minimum payout is $${minPayout}`);
    }

    const transfer = await this.stripe.transfers.create({
      amount: Math.round(amountDollars * 100),
      currency: 'usd',
      destination: merchantStripeAccountId,
    });

    this.logger.log(`Payout transfer: ${transfer.id} · $${amountDollars} → ${merchantStripeAccountId}`);
    return { transferId: transfer.id, amount: amountDollars };
  }

  // ── Create Stripe Connect Account (for merchants) ──
  async createConnectAccount(email: string) {
    const account = await this.stripe.accounts.create({
      type: 'express',
      email,
      capabilities: { transfers: { requested: true } },
    });
    return { accountId: account.id };
  }

  // ── Refund ────────────────────────────────────
  async createRefund(paymentIntentId: string, amountCents?: number) {
    const refund = await this.stripe.refunds.create({
      payment_intent: paymentIntentId,
      ...(amountCents ? { amount: amountCents } : {}),
    });
    return { refundId: refund.id, status: refund.status };
  }

  // ── Private ───────────────────────────────────
  private async onPaymentSucceeded(intent: Stripe.PaymentIntent) {
    this.logger.log(`Payment succeeded: ${intent.id} · $${intent.amount / 100}`);
    // TODO: find order by metadata.orderId, confirm it
  }

  private async onPaymentFailed(intent: Stripe.PaymentIntent) {
    this.logger.warn(`Payment failed: ${intent.id}`);
    // TODO: mark order as payment_failed, notify customer
  }
}

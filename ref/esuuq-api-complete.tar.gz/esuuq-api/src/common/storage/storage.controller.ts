import { Controller, Post, Body, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { IsString, IsNumber, IsEnum, Min, Max } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { StorageService } from './storage.service';
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { CurrentUser } from '../decorators/current-user.decorator';
import { User } from '../../database/entities/user.entity';

class PresignDto {
  @ApiProperty({ enum: ['avatars','products','reviews','merchants','documents'] })
  @IsEnum(['avatars','products','reviews','merchants','documents'])
  folder: any;

  @ApiProperty({ example: 'image/jpeg' })
  @IsString()
  mimeType: string;

  @ApiProperty({ example: 1048576, description: 'File size in bytes' })
  @IsNumber() @Min(1) @Max(10 * 1024 * 1024)
  fileSizeBytes: number;
}

@ApiTags('storage')
@ApiBearerAuth('access-token')
@UseGuards(JwtAuthGuard)
@Controller('storage')
export class StorageController {
  constructor(private readonly storageService: StorageService) {}

  @Post('presign')
  @ApiOperation({
    summary: 'Get a presigned S3 URL for direct browser upload',
    description: `
      1. Call this endpoint to get an uploadUrl.
      2. PUT your file directly to uploadUrl from the browser (no auth header needed).
      3. Store the returned fileUrl in your data (product image, avatar, etc).
    `,
  })
  presign(@Body() dto: PresignDto, @CurrentUser() user: User) {
    return this.storageService.getPresignedUploadUrl(
      dto.folder, dto.mimeType, dto.fileSizeBytes, user.id,
    );
  }
}

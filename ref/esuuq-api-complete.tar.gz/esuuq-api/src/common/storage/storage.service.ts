import { Injectable, BadRequestException, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  S3Client, PutObjectCommand, DeleteObjectCommand, GetObjectCommand,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { ulid } from 'ulid';

type UploadFolder = 'avatars' | 'products' | 'reviews' | 'merchants' | 'documents';

const ALLOWED_MIME_TYPES = [
  'image/jpeg', 'image/png', 'image/webp', 'image/gif',
];

const MAX_SIZES: Record<UploadFolder, number> = {
  avatars:   2 * 1024 * 1024,   // 2 MB
  products:  5 * 1024 * 1024,   // 5 MB
  reviews:   5 * 1024 * 1024,   // 5 MB
  merchants: 5 * 1024 * 1024,   // 5 MB
  documents: 10 * 1024 * 1024,  // 10 MB
};

export interface PresignedUploadResult {
  uploadUrl: string;   // PUT this URL directly from the browser
  fileUrl: string;     // CDN URL to store in DB after upload
  key: string;         // S3 key
  expiresIn: number;   // seconds
}

@Injectable()
export class StorageService {
  private readonly s3: S3Client;
  private readonly bucket: string;
  private readonly cdnUrl: string;
  private readonly logger = new Logger(StorageService.name);

  constructor(private readonly config: ConfigService) {
    this.s3 = new S3Client({
      region: config.get<string>('AWS_REGION', 'us-east-1'),
      credentials: {
        accessKeyId:     config.get<string>('AWS_ACCESS_KEY_ID', ''),
        secretAccessKey: config.get<string>('AWS_SECRET_ACCESS_KEY', ''),
      },
    });
    this.bucket = config.get<string>('AWS_S3_BUCKET', 'esuuq-assets');
    this.cdnUrl = config.get<string>('AWS_CLOUDFRONT_URL', `https://${this.bucket}.s3.amazonaws.com`);
  }

  // ── Presigned URL for direct browser upload ───
  async getPresignedUploadUrl(
    folder: UploadFolder,
    mimeType: string,
    fileSizeBytes: number,
    userId: string,
  ): Promise<PresignedUploadResult> {
    if (!ALLOWED_MIME_TYPES.includes(mimeType)) {
      throw new BadRequestException(
        `File type "${mimeType}" is not allowed. Accepted: ${ALLOWED_MIME_TYPES.join(', ')}`,
      );
    }

    const maxSize = MAX_SIZES[folder];
    if (fileSizeBytes > maxSize) {
      throw new BadRequestException(
        `File too large. Maximum size for ${folder}: ${maxSize / (1024 * 1024)}MB`,
      );
    }

    const ext    = mimeType.split('/')[1].replace('jpeg', 'jpg');
    const key    = `${folder}/${userId}/${ulid()}.${ext}`;
    const expiresIn = 300; // 5 minutes to complete the upload

    const command = new PutObjectCommand({
      Bucket:      this.bucket,
      Key:         key,
      ContentType: mimeType,
      ContentLength: fileSizeBytes,
      Metadata:    { uploadedBy: userId, folder },
    });

    const uploadUrl = await getSignedUrl(this.s3, command, { expiresIn });

    return {
      uploadUrl,
      fileUrl: `${this.cdnUrl}/${key}`,
      key,
      expiresIn,
    };
  }

  // ── Delete a file by key ──────────────────────
  async deleteFile(key: string): Promise<void> {
    try {
      await this.s3.send(
        new DeleteObjectCommand({ Bucket: this.bucket, Key: key }),
      );
      this.logger.log(`Deleted S3 object: ${key}`);
    } catch (err) {
      this.logger.error(`Failed to delete S3 object ${key}:`, err.message);
    }
  }

  // ── Extract key from a CDN URL ────────────────
  keyFromUrl(fileUrl: string): string | null {
    try {
      const url = new URL(fileUrl);
      return url.pathname.replace(/^\//, '');
    } catch {
      return null;
    }
  }

  // ── Presigned read URL (for private files) ────
  async getPresignedReadUrl(key: string, expiresIn = 3600): Promise<string> {
    const command = new GetObjectCommand({ Bucket: this.bucket, Key: key });
    return getSignedUrl(this.s3, command, { expiresIn });
  }
}

import {
  Injectable, NotFoundException, ForbiddenException,
  BadRequestException, Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, FindManyOptions, ILike, Between, MoreThanOrEqual, LessThanOrEqual } from 'typeorm';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Inject } from '@nestjs/common';
import { Cache } from 'cache-manager';
import slugify from 'slugify';
import { ulid } from 'ulid';

import { Product, ProductStatus } from '../database/entities/product.entity';
import { User, UserRole } from '../database/entities/user.entity';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { ProductQueryDto } from './dto/product-query.dto';
import { NotificationsService } from '../notifications/notifications.service';

@Injectable()
export class ProductsService {
  private readonly logger = new Logger(ProductsService.name);
  private readonly CACHE_TTL = 60_000; // 60s

  constructor(
    @InjectRepository(Product)
    private readonly productsRepo: Repository<Product>,

    private readonly notifications: NotificationsService,

    @Inject(CACHE_MANAGER)
    private readonly cache: Cache,
  ) {}

  // ── List / Search ─────────────────────────────
  async findAll(query: ProductQueryDto) {
    const {
      page = 1, limit = 20, q, category, merchant,
      minPrice, maxPrice, inStock, sort = 'newest', featured,
    } = query;

    const where: any = { status: ProductStatus.ACTIVE };
    if (category)  where.categoryId = category;
    if (merchant)  where.merchantId = merchant;
    if (featured)  where.isFeatured = true;
    if (inStock)   where.stock = MoreThanOrEqual(1);
    if (q)         where.name = ILike(`%${q}%`);
    if (minPrice && maxPrice) where.price = Between(minPrice, maxPrice);
    else if (minPrice) where.price = MoreThanOrEqual(minPrice);
    else if (maxPrice) where.price = LessThanOrEqual(maxPrice);

    const orderMap: Record<string, any> = {
      newest:     { createdAt: 'DESC' },
      popular:    { totalSold: 'DESC' },
      price_asc:  { price: 'ASC' },
      price_desc: { price: 'DESC' },
      rating:     { avgRating: 'DESC' },
    };

    const [data, total] = await this.productsRepo.findAndCount({
      where,
      order: orderMap[sort] ?? { createdAt: 'DESC' },
      skip: (page - 1) * limit,
      take: Math.min(limit, 100),
      relations: ['merchant', 'category'],
      select: {
        id: true, name: true, slug: true, price: true, comparePrice: true,
        stock: true, images: true, avgRating: true, reviewCount: true,
        status: true, isFeatured: true, totalSold: true,
        merchant: { id: true, storeName: true, storeSlug: true, avgRating: true },
        category: { id: true, name: true, slug: true },
      },
    });

    return {
      data,
      meta: { total, page, limit, pages: Math.ceil(total / limit) },
    };
  }

  // ── Get One ───────────────────────────────────
  async findOne(id: string) {
    const cacheKey = `product:${id}`;
    const cached = await this.cache.get<Product>(cacheKey);
    if (cached) return cached;

    const product = await this.productsRepo.findOne({
      where: { id, status: ProductStatus.ACTIVE },
      relations: ['merchant', 'category', 'reviews'],
    });

    if (!product) throw new NotFoundException(`Product ${id} not found`);

    await this.cache.set(cacheKey, product, this.CACHE_TTL);
    return product;
  }

  async findBySlug(slug: string) {
    const product = await this.productsRepo.findOne({
      where: { slug, status: ProductStatus.ACTIVE },
      relations: ['merchant', 'category'],
    });
    if (!product) throw new NotFoundException(`Product "${slug}" not found`);
    return product;
  }

  // ── Create ────────────────────────────────────
  async create(dto: CreateProductDto, merchantId: string) {
    const slug = await this.generateSlug(dto.name);

    const product = this.productsRepo.create({
      ...dto,
      id: ulid(),
      merchantId,
      slug,
      status: ProductStatus.ACTIVE,
    });

    const saved = await this.productsRepo.save(product);
    this.logger.log(`Product created: ${saved.id} by merchant ${merchantId}`);
    return saved;
  }

  // ── Update ────────────────────────────────────
  async update(id: string, dto: UpdateProductDto, user: User) {
    const product = await this.productsRepo.findOneBy({ id });
    if (!product) throw new NotFoundException(`Product ${id} not found`);

    // Only owning merchant or admin can update
    if (user.role !== UserRole.ADMIN && user.role !== UserRole.SUPER_ADMIN) {
      const merchant = await this.getMerchantByUserId(user.id);
      if (product.merchantId !== merchant?.id) {
        throw new ForbiddenException('You do not own this product');
      }
    }

    if (dto.name && dto.name !== product.name) {
      (dto as any).slug = await this.generateSlug(dto.name, id);
    }

    const updated = await this.productsRepo.save({ ...product, ...dto });

    // Invalidate cache
    await this.cache.del(`product:${id}`);

    // Check low-stock alert
    if (updated.stock <= updated.lowStockAt) {
      await this.notifications.sendLowStockAlert(updated.merchantId, updated);
    }

    return updated;
  }

  // ── Restock (inventory update) ────────────────
  async restock(id: string, quantity: number, merchantId: string) {
    const product = await this.productsRepo.findOneBy({ id });
    if (!product) throw new NotFoundException('Product not found');
    if (product.merchantId !== merchantId) throw new ForbiddenException();

    product.stock += quantity;
    if (product.stock > 0 && product.status === ProductStatus.OUT_OF_STOCK) {
      product.status = ProductStatus.ACTIVE;
    }

    await this.productsRepo.save(product);
    await this.cache.del(`product:${id}`);
    return { id, newStock: product.stock };
  }

  // ── Soft Delete ───────────────────────────────
  async remove(id: string, user: User) {
    const product = await this.findOne(id);
    if (user.role !== UserRole.ADMIN && user.role !== UserRole.SUPER_ADMIN) {
      const merchant = await this.getMerchantByUserId(user.id);
      if (product.merchantId !== merchant?.id) throw new ForbiddenException();
    }
    await this.productsRepo.softDelete(id);
    await this.cache.del(`product:${id}`);
    return { message: 'Product removed' };
  }

  // ── Private Helpers ───────────────────────────
  private async generateSlug(name: string, excludeId?: string): Promise<string> {
    let base = slugify(name, { lower: true, strict: true });
    let slug = base;
    let count = 1;

    while (true) {
      const existing = await this.productsRepo.findOne({ where: { slug } });
      if (!existing || existing.id === excludeId) break;
      slug = `${base}-${count++}`;
    }
    return slug;
  }

  private async getMerchantByUserId(userId: string) {
    // Lazy import to avoid circular deps
    const { Merchant } = await import('../database/entities/supporting.entities');
    return null; // resolved via MerchantsService in real impl
  }
}

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BullModule } from '@nestjs/bull';
import { Order, OrderItem } from '../database/entities/order.entity';
import { Product } from '../database/entities/product.entity';
import { OrdersService } from './orders.service';
import { OrdersController } from './orders.controller';
import { OrdersProcessor } from './orders.processor';
import { NotificationsModule } from '../notifications/notifications.module';
@Module({
  imports: [
    TypeOrmModule.forFeature([Order, OrderItem, Product]),
    BullModule.registerQueue({ name: 'orders' }),
    NotificationsModule,
  ],
  providers: [OrdersService, OrdersProcessor],
  controllers: [OrdersController],
  exports: [OrdersService],
})
export class OrdersModule {}

import { Processor, Process, OnQueueFailed } from '@nestjs/bull';
import { Job } from 'bull';
import { Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Order } from '../database/entities/order.entity';
import { User } from '../database/entities/user.entity';
import { NotificationsService } from '../notifications/notifications.service';

interface OrderConfirmedJob {
  orderId: string;
  customerId: string;
  otp: string;
  total: number;
}

interface StatusChangedJob {
  orderId: string;
  newStatus: string;
  customerId: string;
}

@Processor('orders')
export class OrdersProcessor {
  private readonly logger = new Logger(OrdersProcessor.name);

  constructor(
    @InjectRepository(Order) private readonly ordersRepo: Repository<Order>,
    @InjectRepository(User)  private readonly usersRepo: Repository<User>,
    private readonly notifications: NotificationsService,
  ) {}

  @Process('order-confirmed')
  async handleOrderConfirmed(job: Job<OrderConfirmedJob>) {
    const { orderId, customerId, otp, total } = job.data;
    this.logger.log(`Processing order-confirmed job: ${orderId}`);

    const user = await this.usersRepo.findOneBy({ id: customerId });
    if (!user?.email) return;

    await this.notifications.sendOrderConfirmation(user.email, orderId, total, otp);

    // TODO: notify merchant(s) about new order
    // TODO: find nearby available driver and push new-order notification
  }

  @Process('status-changed')
  async handleStatusChanged(job: Job<StatusChangedJob>) {
    const { orderId, newStatus, customerId } = job.data;
    this.logger.log(`Status changed: ${orderId} → ${newStatus}`);

    const user = await this.usersRepo.findOneBy({ id: customerId });
    if (!user?.email) return;

    await this.notifications.sendOrderStatusUpdate(user.email, orderId, newStatus);
  }

  @OnQueueFailed()
  handleFailed(job: Job, err: Error) {
    this.logger.error(`Job failed: ${job.name} #${job.id} — ${err.message}`);
  }
}

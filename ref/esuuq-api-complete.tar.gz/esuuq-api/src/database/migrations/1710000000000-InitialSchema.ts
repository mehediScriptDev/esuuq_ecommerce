import { MigrationInterface, QueryRunner } from 'typeorm';

export class InitialSchema1710000000000 implements MigrationInterface {
  name = 'InitialSchema1710000000000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // ── Extensions ──
    await queryRunner.query(`CREATE EXTENSION IF NOT EXISTS "pg_trgm"`);
    await queryRunner.query(`CREATE EXTENSION IF NOT EXISTS "unaccent"`);

    // ── ENUMS ──
    await queryRunner.query(`
      CREATE TYPE user_role_enum AS ENUM
        ('customer','merchant','delivery_partner','sub_admin','admin','super_admin')
    `);
    await queryRunner.query(`
      CREATE TYPE auth_provider_enum AS ENUM ('local','google','facebook')
    `);
    await queryRunner.query(`
      CREATE TYPE order_status_enum AS ENUM (
        'pending_payment','confirmed','processing','ready_for_pickup',
        'picked_up','in_transit','delivered','cancelled',
        'return_requested','returned','refunded'
      )
    `);
    await queryRunner.query(`
      CREATE TYPE shipping_method_enum AS ENUM ('free','express','next_day')
    `);
    await queryRunner.query(`
      CREATE TYPE product_status_enum AS ENUM
        ('active','inactive','out_of_stock','pending_review','rejected')
    `);
    await queryRunner.query(`
      CREATE TYPE merchant_status_enum AS ENUM ('pending','approved','suspended','rejected')
    `);

    // ── USERS ──
    await queryRunner.query(`
      CREATE TABLE users (
        id               VARCHAR(26)         PRIMARY KEY,
        first_name       VARCHAR(80)         NOT NULL,
        last_name        VARCHAR(80)         NOT NULL,
        email            VARCHAR(255)        NOT NULL UNIQUE,
        phone            VARCHAR(20)         UNIQUE,
        password_hash    VARCHAR(255),
        role             user_role_enum      NOT NULL DEFAULT 'customer',
        provider         auth_provider_enum  NOT NULL DEFAULT 'local',
        provider_id      VARCHAR(200),
        is_verified      BOOLEAN             NOT NULL DEFAULT FALSE,
        is_active        BOOLEAN             NOT NULL DEFAULT TRUE,
        avatar_url       VARCHAR(500),
        refresh_token_hash VARCHAR(255),
        last_login_at    TIMESTAMPTZ,
        created_at       TIMESTAMPTZ         NOT NULL DEFAULT NOW(),
        updated_at       TIMESTAMPTZ         NOT NULL DEFAULT NOW(),
        deleted_at       TIMESTAMPTZ
      )
    `);
    await queryRunner.query(`CREATE INDEX idx_users_email ON users(email)`);
    await queryRunner.query(`CREATE INDEX idx_users_role  ON users(role)`);

    // ── CATEGORIES ──
    await queryRunner.query(`
      CREATE TABLE categories (
        id          VARCHAR(26)  PRIMARY KEY,
        name        VARCHAR(80)  NOT NULL UNIQUE,
        slug        VARCHAR(90)  NOT NULL UNIQUE,
        icon_url    VARCHAR(500),
        parent_id   VARCHAR(26)  REFERENCES categories(id),
        is_active   BOOLEAN      NOT NULL DEFAULT TRUE,
        sort_order  INTEGER      NOT NULL DEFAULT 0,
        created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
        updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
        deleted_at  TIMESTAMPTZ
      )
    `);

    // ── MERCHANTS ──
    await queryRunner.query(`
      CREATE TABLE merchants (
        id                VARCHAR(26)           PRIMARY KEY,
        user_id           VARCHAR(26)           NOT NULL UNIQUE REFERENCES users(id),
        store_name        VARCHAR(120)          NOT NULL,
        store_slug        VARCHAR(130)          NOT NULL UNIQUE,
        description       TEXT,
        logo_url          VARCHAR(500),
        banner_url        VARCHAR(500),
        status            merchant_status_enum  NOT NULL DEFAULT 'pending',
        is_verified       BOOLEAN               NOT NULL DEFAULT FALSE,
        is_online         BOOLEAN               NOT NULL DEFAULT TRUE,
        commission_rate   DECIMAL(5,2)          NOT NULL DEFAULT 8.0,
        total_revenue     DECIMAL(10,2)         NOT NULL DEFAULT 0,
        available_balance DECIMAL(10,2)         NOT NULL DEFAULT 0,
        stripe_account_id VARCHAR(100),
        avg_rating        DECIMAL(3,1)          NOT NULL DEFAULT 0,
        return_policy_days INTEGER              NOT NULL DEFAULT 30,
        business_info     JSONB,
        created_at        TIMESTAMPTZ           NOT NULL DEFAULT NOW(),
        updated_at        TIMESTAMPTZ           NOT NULL DEFAULT NOW(),
        deleted_at        TIMESTAMPTZ
      )
    `);

    // ── PRODUCTS ──
    await queryRunner.query(`
      CREATE TABLE products (
        id            VARCHAR(26)           PRIMARY KEY,
        merchant_id   VARCHAR(26)           NOT NULL REFERENCES merchants(id),
        category_id   VARCHAR(26)           NOT NULL REFERENCES categories(id),
        name          VARCHAR(200)          NOT NULL,
        slug          VARCHAR(220)          NOT NULL UNIQUE,
        description   TEXT                  NOT NULL,
        price         DECIMAL(10,2)         NOT NULL,
        compare_price DECIMAL(10,2),
        stock         INTEGER               NOT NULL DEFAULT 0,
        sku           VARCHAR(100)          UNIQUE,
        low_stock_at  INTEGER               NOT NULL DEFAULT 10,
        status        product_status_enum   NOT NULL DEFAULT 'active',
        images        JSONB                 NOT NULL DEFAULT '[]',
        variants      JSONB,
        avg_rating    DECIMAL(3,1)          NOT NULL DEFAULT 0,
        review_count  INTEGER               NOT NULL DEFAULT 0,
        total_sold    INTEGER               NOT NULL DEFAULT 0,
        is_featured   BOOLEAN               NOT NULL DEFAULT FALSE,
        metadata      JSONB,
        created_at    TIMESTAMPTZ           NOT NULL DEFAULT NOW(),
        updated_at    TIMESTAMPTZ           NOT NULL DEFAULT NOW(),
        deleted_at    TIMESTAMPTZ
      )
    `);
    await queryRunner.query(`CREATE INDEX idx_products_merchant  ON products(merchant_id)`);
    await queryRunner.query(`CREATE INDEX idx_products_category  ON products(category_id)`);
    await queryRunner.query(`CREATE INDEX idx_products_status    ON products(status)`);
    await queryRunner.query(`CREATE INDEX idx_products_fts ON products USING gin(to_tsvector('english', name))`);

    // ── ADDRESSES ──
    await queryRunner.query(`
      CREATE TABLE addresses (
        id            VARCHAR(26)  PRIMARY KEY,
        user_id       VARCHAR(26)  NOT NULL REFERENCES users(id),
        type          VARCHAR(20)  NOT NULL DEFAULT 'home',
        full_name     VARCHAR(160) NOT NULL,
        phone         VARCHAR(20)  NOT NULL,
        address_line1 VARCHAR(300) NOT NULL,
        address_line2 VARCHAR(200),
        city          VARCHAR(100) NOT NULL,
        state         VARCHAR(100) NOT NULL,
        zip_code      VARCHAR(20)  NOT NULL,
        country       VARCHAR(80)  NOT NULL DEFAULT 'United States',
        is_default    BOOLEAN      NOT NULL DEFAULT FALSE,
        lat           DECIMAL(9,6),
        lng           DECIMAL(9,6),
        created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
        updated_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
        deleted_at    TIMESTAMPTZ
      )
    `);
    await queryRunner.query(`CREATE INDEX idx_addresses_user ON addresses(user_id)`);

    // ── ORDERS ──
    await queryRunner.query(`
      CREATE TABLE orders (
        id                       VARCHAR(20)          PRIMARY KEY,
        customer_id              VARCHAR(26)          NOT NULL REFERENCES users(id),
        driver_id                VARCHAR(26)          REFERENCES users(id),
        address_id               VARCHAR(26)          NOT NULL REFERENCES addresses(id),
        status                   order_status_enum    NOT NULL DEFAULT 'pending_payment',
        shipping_method          shipping_method_enum NOT NULL DEFAULT 'free',
        subtotal                 DECIMAL(10,2)        NOT NULL,
        shipping_fee             DECIMAL(10,2)        NOT NULL DEFAULT 0,
        discount                 DECIMAL(10,2)        NOT NULL DEFAULT 0,
        total                    DECIMAL(10,2)        NOT NULL,
        coupon_code              VARCHAR(30),
        stripe_payment_intent_id VARCHAR(200),
        delivery_otp             VARCHAR(60),
        status_history           JSONB                NOT NULL DEFAULT '[]',
        estimated_delivery       DATE,
        delivered_at             TIMESTAMPTZ,
        cancelled_at             TIMESTAMPTZ,
        cancel_reason            TEXT,
        created_at               TIMESTAMPTZ          NOT NULL DEFAULT NOW(),
        updated_at               TIMESTAMPTZ          NOT NULL DEFAULT NOW()
      )
    `);
    await queryRunner.query(`CREATE INDEX idx_orders_customer   ON orders(customer_id)`);
    await queryRunner.query(`CREATE INDEX idx_orders_driver     ON orders(driver_id)`);
    await queryRunner.query(`CREATE INDEX idx_orders_status     ON orders(status)`);
    await queryRunner.query(`CREATE INDEX idx_orders_created_at ON orders(created_at DESC)`);

    // ── ORDER ITEMS ──
    await queryRunner.query(`
      CREATE TABLE order_items (
        id               VARCHAR(26)  PRIMARY KEY,
        order_id         VARCHAR(20)  NOT NULL REFERENCES orders(id),
        product_id       VARCHAR(26)  NOT NULL REFERENCES products(id),
        merchant_id      VARCHAR(26)  NOT NULL REFERENCES merchants(id),
        quantity         INTEGER      NOT NULL,
        unit_price       DECIMAL(10,2) NOT NULL,
        total_price      DECIMAL(10,2) NOT NULL,
        commission       DECIMAL(10,2) NOT NULL DEFAULT 0,
        merchant_earnings DECIMAL(10,2) NOT NULL DEFAULT 0,
        variant_id       VARCHAR(26),
        variant_snapshot JSONB,
        product_name     VARCHAR(200) NOT NULL,
        product_image    VARCHAR(500)
      )
    `);
    await queryRunner.query(`CREATE INDEX idx_order_items_order    ON order_items(order_id)`);
    await queryRunner.query(`CREATE INDEX idx_order_items_merchant ON order_items(merchant_id)`);

    // ── REVIEWS ──
    await queryRunner.query(`
      CREATE TABLE reviews (
        id                   VARCHAR(26)  PRIMARY KEY,
        product_id           VARCHAR(26)  NOT NULL REFERENCES products(id),
        user_id              VARCHAR(26)  NOT NULL REFERENCES users(id),
        order_id             VARCHAR(20)  NOT NULL REFERENCES orders(id),
        rating               SMALLINT     NOT NULL CHECK (rating BETWEEN 1 AND 5),
        comment              TEXT,
        images               JSONB,
        is_verified_purchase BOOLEAN      NOT NULL DEFAULT TRUE,
        merchant_reply       TEXT,
        merchant_replied_at  TIMESTAMPTZ,
        created_at           TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
        updated_at           TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
        deleted_at           TIMESTAMPTZ
      )
    `);

    // ── WISHLIST ──
    await queryRunner.query(`
      CREATE TABLE wishlist (
        id         VARCHAR(26)  PRIMARY KEY,
        user_id    VARCHAR(26)  NOT NULL REFERENCES users(id),
        product_id VARCHAR(26)  NOT NULL REFERENCES products(id),
        created_at TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
        UNIQUE(user_id, product_id)
      )
    `);

    // ── COUPONS ──
    await queryRunner.query(`
      CREATE TABLE coupons (
        id              VARCHAR(26)    PRIMARY KEY,
        code            VARCHAR(30)    NOT NULL UNIQUE,
        type            VARCHAR(20)    NOT NULL, -- percentage | flat
        value           DECIMAL(10,2)  NOT NULL,
        min_order_value DECIMAL(10,2),
        max_uses        INTEGER,
        used_count      INTEGER        NOT NULL DEFAULT 0,
        expires_at      TIMESTAMPTZ,
        is_active       BOOLEAN        NOT NULL DEFAULT TRUE,
        created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
      )
    `);

    // ── SEED: Default categories ──
    const cats = [
      ['01HZ0001', 'Electronics',    'electronics'],
      ['01HZ0002', 'Fashion',        'fashion'],
      ['01HZ0003', 'Home & Garden',  'home-garden'],
      ['01HZ0004', 'Beauty',         'beauty'],
      ['01HZ0005', 'Sports',         'sports'],
      ['01HZ0006', 'Books',          'books'],
      ['01HZ0007', 'Toys',           'toys'],
      ['01HZ0008', 'Automotive',     'automotive'],
      ['01HZ0009', 'Food & Grocery', 'food-grocery'],
      ['01HZ0010', 'Health',         'health'],
      ['01HZ0011', 'Office',         'office'],
      ['01HZ0012', 'Pet Supplies',   'pet-supplies'],
    ];
    for (const [id, name, slug] of cats) {
      await queryRunner.query(
        `INSERT INTO categories(id, name, slug, sort_order) VALUES ($1, $2, $3, $4)`,
        [id, name, slug, cats.indexOf([id, name, slug])],
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS wishlist CASCADE`);
    await queryRunner.query(`DROP TABLE IF EXISTS reviews CASCADE`);
    await queryRunner.query(`DROP TABLE IF EXISTS order_items CASCADE`);
    await queryRunner.query(`DROP TABLE IF EXISTS orders CASCADE`);
    await queryRunner.query(`DROP TABLE IF EXISTS addresses CASCADE`);
    await queryRunner.query(`DROP TABLE IF EXISTS products CASCADE`);
    await queryRunner.query(`DROP TABLE IF EXISTS merchants CASCADE`);
    await queryRunner.query(`DROP TABLE IF EXISTS categories CASCADE`);
    await queryRunner.query(`DROP TABLE IF EXISTS users CASCADE`);
    await queryRunner.query(`DROP TABLE IF EXISTS coupons CASCADE`);
    await queryRunner.query(`DROP TYPE IF EXISTS user_role_enum`);
    await queryRunner.query(`DROP TYPE IF EXISTS auth_provider_enum`);
    await queryRunner.query(`DROP TYPE IF EXISTS order_status_enum`);
    await queryRunner.query(`DROP TYPE IF EXISTS shipping_method_enum`);
    await queryRunner.query(`DROP TYPE IF EXISTS product_status_enum`);
    await queryRunner.query(`DROP TYPE IF EXISTS merchant_status_enum`);
  }
}

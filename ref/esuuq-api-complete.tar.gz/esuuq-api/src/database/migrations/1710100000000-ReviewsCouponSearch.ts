import { MigrationInterface, QueryRunner } from 'typeorm';

export class ReviewsCouponSearch1710100000000 implements MigrationInterface {
  name = 'ReviewsCouponSearch1710100000000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // ── ENUMs ──
    await queryRunner.query(`
      CREATE TYPE review_status_enum AS ENUM ('pending','approved','rejected','flagged')
    `);
    await queryRunner.query(`
      CREATE TYPE coupon_type_enum AS ENUM ('percentage','flat','free_shipping')
    `);
    await queryRunner.query(`
      CREATE TYPE coupon_scope_enum AS ENUM
        ('all','category','merchant','product','first_order')
    `);

    // ── REVIEWS ──
    await queryRunner.query(`
      CREATE TABLE reviews (
        id                   VARCHAR(26)         PRIMARY KEY,
        product_id           VARCHAR(26)         NOT NULL REFERENCES products(id),
        user_id              VARCHAR(26)         NOT NULL REFERENCES users(id),
        order_id             VARCHAR(20)         NOT NULL REFERENCES orders(id),
        merchant_id          VARCHAR(26),
        rating               SMALLINT            NOT NULL CHECK (rating BETWEEN 1 AND 5),
        title                VARCHAR(120),
        comment              TEXT,
        images               JSONB               NOT NULL DEFAULT '[]',
        is_verified_purchase BOOLEAN             NOT NULL DEFAULT TRUE,
        helpful_count        INTEGER             NOT NULL DEFAULT 0,
        status               review_status_enum  NOT NULL DEFAULT 'approved',
        merchant_reply       TEXT,
        merchant_replied_at  TIMESTAMPTZ,
        created_at           TIMESTAMPTZ         NOT NULL DEFAULT NOW(),
        updated_at           TIMESTAMPTZ         NOT NULL DEFAULT NOW(),
        deleted_at           TIMESTAMPTZ
      )
    `);
    await queryRunner.query(`CREATE INDEX idx_reviews_product   ON reviews(product_id)`);
    await queryRunner.query(`CREATE INDEX idx_reviews_user      ON reviews(user_id)`);
    await queryRunner.query(`CREATE INDEX idx_reviews_order     ON reviews(order_id)`);
    await queryRunner.query(`CREATE INDEX idx_reviews_merchant  ON reviews(merchant_id)`);
    await queryRunner.query(`CREATE INDEX idx_reviews_status    ON reviews(status)`);
    await queryRunner.query(`
      CREATE INDEX idx_reviews_product_status
        ON reviews(product_id, status) WHERE deleted_at IS NULL
    `);

    // ── REVIEW HELPFUL ──
    await queryRunner.query(`
      CREATE TABLE review_helpful (
        id         VARCHAR(26)  PRIMARY KEY,
        review_id  VARCHAR(26)  NOT NULL REFERENCES reviews(id) ON DELETE CASCADE,
        user_id    VARCHAR(26)  NOT NULL REFERENCES users(id),
        created_at TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
        UNIQUE(review_id, user_id)
      )
    `);
    await queryRunner.query(`CREATE INDEX idx_review_helpful ON review_helpful(review_id)`);

    // ── COUPONS ──
    await queryRunner.query(`
      CREATE TABLE coupons (
        id                VARCHAR(26)          PRIMARY KEY,
        code              VARCHAR(30)          NOT NULL UNIQUE,
        description       TEXT,
        type              coupon_type_enum     NOT NULL,
        value             DECIMAL(10,2)        NOT NULL,
        max_discount      DECIMAL(10,2),
        min_order_value   DECIMAL(10,2),
        scope             coupon_scope_enum    NOT NULL DEFAULT 'all',
        scope_id          VARCHAR(26),
        max_uses          INTEGER,
        used_count        INTEGER              NOT NULL DEFAULT 0,
        max_uses_per_user INTEGER,
        is_active         BOOLEAN              NOT NULL DEFAULT TRUE,
        starts_at         TIMESTAMPTZ,
        expires_at        TIMESTAMPTZ,
        created_by        VARCHAR(26),
        created_at        TIMESTAMPTZ          NOT NULL DEFAULT NOW(),
        updated_at        TIMESTAMPTZ          NOT NULL DEFAULT NOW(),
        deleted_at        TIMESTAMPTZ
      )
    `);
    await queryRunner.query(`CREATE INDEX idx_coupons_code       ON coupons(code)`);
    await queryRunner.query(`CREATE INDEX idx_coupons_active     ON coupons(is_active)`);
    await queryRunner.query(`CREATE INDEX idx_coupons_expires_at ON coupons(expires_at)`);

    // ── COUPON USAGES ──
    await queryRunner.query(`
      CREATE TABLE coupon_usages (
        id               VARCHAR(26)   PRIMARY KEY,
        coupon_id        VARCHAR(26)   NOT NULL REFERENCES coupons(id),
        user_id          VARCHAR(26)   NOT NULL REFERENCES users(id),
        order_id         VARCHAR(20)   NOT NULL UNIQUE REFERENCES orders(id),
        discount_applied DECIMAL(10,2) NOT NULL,
        used_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW()
      )
    `);
    await queryRunner.query(`
      CREATE INDEX idx_coupon_usages_coupon_user ON coupon_usages(coupon_id, user_id)
    `);

    // ── SEARCH LOGS (for trending queries) ──
    await queryRunner.query(`
      CREATE TABLE search_logs (
        id             UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
        query          VARCHAR(200) NOT NULL,
        results_count  INTEGER      NOT NULL DEFAULT 0,
        user_id        VARCHAR(26),
        created_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW()
      )
    `);
    await queryRunner.query(`CREATE INDEX idx_search_logs_query      ON search_logs(query)`);
    await queryRunner.query(`CREATE INDEX idx_search_logs_created_at ON search_logs(created_at DESC)`);

    // ── SEED: Demo coupons ──
    await queryRunner.query(`
      INSERT INTO coupons (id, code, description, type, value, scope, max_uses, is_active, expires_at)
      VALUES
        ('01HZ0C01', 'ESUUQ10',  '10% off any order',         'percentage', 10,   'all', 1000, true, NOW() + INTERVAL '90 days'),
        ('01HZ0C02', 'SAVE10',   '$10 off orders over $50',   'flat',       10,   'all',  500, true, NOW() + INTERVAL '30 days'),
        ('01HZ0C03', 'FREESHIP', 'Free shipping on any order','free_shipping', 0, 'all', 200,  true, NOW() + INTERVAL '14 days'),
        ('01HZ0C04', 'WELCOME25','25% off your first order',  'percentage', 25,   'first_order', NULL, true, NULL)
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS search_logs CASCADE`);
    await queryRunner.query(`DROP TABLE IF EXISTS coupon_usages CASCADE`);
    await queryRunner.query(`DROP TABLE IF EXISTS coupons CASCADE`);
    await queryRunner.query(`DROP TABLE IF EXISTS review_helpful CASCADE`);
    await queryRunner.query(`DROP TABLE IF EXISTS reviews CASCADE`);
    await queryRunner.query(`DROP TYPE IF EXISTS review_status_enum`);
    await queryRunner.query(`DROP TYPE IF EXISTS coupon_type_enum`);
    await queryRunner.query(`DROP TYPE IF EXISTS coupon_scope_enum`);
  }
}

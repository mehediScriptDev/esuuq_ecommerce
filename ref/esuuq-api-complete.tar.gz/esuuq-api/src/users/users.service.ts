import {
  Injectable, NotFoundException, BadRequestException,
  ConflictException, ForbiddenException, Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';

import { User, UserRole } from '../database/entities/user.entity';
import { Address, Wishlist } from '../database/entities/supporting.entities';
import { Product } from '../database/entities/product.entity';

@Injectable()
export class UsersService {
  private readonly logger = new Logger(UsersService.name);

  constructor(
    @InjectRepository(User)    private readonly usersRepo: Repository<User>,
    @InjectRepository(Address) private readonly addressesRepo: Repository<Address>,
    @InjectRepository(Wishlist) private readonly wishlistRepo: Repository<Wishlist>,
    @InjectRepository(Product) private readonly productsRepo: Repository<Product>,
  ) {}

  // ── Profile ───────────────────────────────────
  async findById(id: string): Promise<User> {
    const user = await this.usersRepo.findOne({
      where: { id },
      select: ['id','firstName','lastName','email','phone','role',
               'avatarUrl','isVerified','isActive','provider','createdAt','lastLoginAt'],
    });
    if (!user) throw new NotFoundException('User not found');
    return user;
  }

  async updateProfile(id: string, dto: Partial<Pick<User,'firstName'|'lastName'|'phone'|'avatarUrl'>>): Promise<User> {
    const user = await this.findById(id);
    if (dto.phone && dto.phone !== user.phone) {
      const taken = await this.usersRepo.findOne({ where: { phone: dto.phone } });
      if (taken) throw new ConflictException('Phone number already in use');
    }
    await this.usersRepo.update(id, dto);
    return this.findById(id);
  }

  async changePassword(id: string, currentPassword: string, newPassword: string): Promise<void> {
    const user = await this.usersRepo.findOne({ where: { id }, select: ['id','passwordHash','provider'] });
    if (!user) throw new NotFoundException('User not found');
    if (!user.passwordHash) throw new BadRequestException('Cannot change password on social login accounts');
    const valid = await bcrypt.compare(currentPassword, user.passwordHash);
    if (!valid) throw new BadRequestException('Current password is incorrect');
    if (currentPassword === newPassword) throw new BadRequestException('New password must differ');
    await this.usersRepo.update(id, { passwordHash: await bcrypt.hash(newPassword, 12) });
    this.logger.log(`Password changed: ${id}`);
  }

  async updateAvatar(id: string, avatarUrl: string): Promise<User> {
    await this.usersRepo.update(id, { avatarUrl });
    return this.findById(id);
  }

  async deactivateAccount(id: string, requesterId: string, role: UserRole): Promise<void> {
    if (id !== requesterId && role !== UserRole.ADMIN && role !== UserRole.SUPER_ADMIN) {
      throw new ForbiddenException();
    }
    await this.usersRepo.update(id, { isActive: false });
  }

  // ── Addresses ─────────────────────────────────
  async getAddresses(userId: string): Promise<Address[]> {
    return this.addressesRepo.find({
      where: { userId },
      order: { isDefault: 'DESC', createdAt: 'DESC' },
    });
  }

  async createAddress(userId: string, dto: any): Promise<Address> {
    const count = await this.addressesRepo.count({ where: { userId } });
    if (count >= 10) throw new BadRequestException('Maximum of 10 addresses allowed');
    if (dto.isDefault || count === 0) {
      await this.addressesRepo.update({ userId }, { isDefault: false });
    }
    return this.addressesRepo.save(
      this.addressesRepo.create({ ...dto, userId, isDefault: dto.isDefault || count === 0 }),
    );
  }

  async updateAddress(id: string, userId: string, dto: any): Promise<Address> {
    const address = await this.addressesRepo.findOne({ where: { id } });
    if (!address) throw new NotFoundException('Address not found');
    if (address.userId !== userId) throw new ForbiddenException();
    if (dto.isDefault && !address.isDefault) {
      await this.addressesRepo.update({ userId }, { isDefault: false });
    }
    return this.addressesRepo.save(Object.assign(address, dto));
  }

  async setDefaultAddress(id: string, userId: string): Promise<Address> {
    const address = await this.addressesRepo.findOne({ where: { id } });
    if (!address) throw new NotFoundException();
    if (address.userId !== userId) throw new ForbiddenException();
    await this.addressesRepo.update({ userId }, { isDefault: false });
    await this.addressesRepo.update(id, { isDefault: true });
    return this.addressesRepo.findOneBy({ id });
  }

  async deleteAddress(id: string, userId: string): Promise<void> {
    const address = await this.addressesRepo.findOne({ where: { id } });
    if (!address) throw new NotFoundException();
    if (address.userId !== userId) throw new ForbiddenException();
    if (address.isDefault) throw new BadRequestException('Cannot delete default address. Set another as default first.');
    await this.addressesRepo.softDelete(id);
  }

  // ── Wishlist ──────────────────────────────────
  async getWishlist(userId: string, page = 1, limit = 20) {
    const [data, total] = await this.wishlistRepo.findAndCount({
      where: { userId },
      relations: ['product', 'product.merchant', 'product.category'],
      order: { createdAt: 'DESC' },
      skip: (page - 1) * limit,
      take: limit,
    });
    return {
      data: data.map((w) => w.product),
      meta: { total, page, limit, pages: Math.ceil(total / limit) },
    };
  }

  async toggleWishlist(userId: string, productId: string): Promise<{ wishlisted: boolean }> {
    const product = await this.productsRepo.findOneBy({ id: productId });
    if (!product) throw new NotFoundException('Product not found');
    const existing = await this.wishlistRepo.findOne({ where: { userId, productId } });
    if (existing) {
      await this.wishlistRepo.delete({ userId, productId });
      return { wishlisted: false };
    }
    await this.wishlistRepo.save(this.wishlistRepo.create({ userId, productId }));
    return { wishlisted: true };
  }

  async clearWishlist(userId: string): Promise<void> {
    await this.wishlistRepo.delete({ userId });
  }

  // ── Admin ─────────────────────────────────────
  async findAll(page = 1, limit = 20, role?: UserRole, search?: string) {
    const qb = this.usersRepo.createQueryBuilder('u')
      .select(['u.id','u.firstName','u.lastName','u.email','u.phone',
               'u.role','u.isActive','u.isVerified','u.createdAt','u.lastLoginAt'])
      .where('u.deletedAt IS NULL');
    if (role)   qb.andWhere('u.role = :role', { role });
    if (search) qb.andWhere(
      '(LOWER(u.email) LIKE LOWER(:s) OR LOWER(u.firstName) LIKE LOWER(:s))',
      { s: `%${search}%` },
    );
    qb.orderBy('u.createdAt', 'DESC').skip((page - 1) * limit).take(limit);
    const [data, total] = await qb.getManyAndCount();
    return { data, meta: { total, page, limit, pages: Math.ceil(total / limit) } };
  }

  async adminUpdateUser(id: string, updates: { isActive?: boolean; isVerified?: boolean; role?: UserRole }): Promise<User> {
    await this.usersRepo.update(id, updates);
    return this.findById(id);
  }

  async hardDelete(id: string): Promise<void> {
    const user = await this.findById(id);
    if (user.role === UserRole.SUPER_ADMIN) throw new ForbiddenException('Cannot delete super admin');
    await this.usersRepo.softDelete(id);
  }
}

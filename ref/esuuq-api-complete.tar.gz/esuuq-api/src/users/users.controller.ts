import {
  Controller, Get, Put, Patch, Post, Delete,
  Body, Param, Query, UseGuards, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery } from '@nestjs/swagger';
import { IsString, IsOptional, MinLength, MaxLength, IsBoolean } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { UsersService } from './users.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { Roles } from '../common/decorators/roles.decorator';
import { User, UserRole } from '../database/entities/user.entity';

class UpdateProfileDto {
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(80) firstName?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(80) lastName?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() phone?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() avatarUrl?: string;
}

class ChangePasswordDto {
  @ApiProperty() @IsString() currentPassword: string;
  @ApiProperty() @IsString() @MinLength(8) newPassword: string;
}

class AddressDto {
  @ApiPropertyOptional() @IsOptional() @IsString() type?: string;
  @ApiProperty() @IsString() fullName: string;
  @ApiProperty() @IsString() phone: string;
  @ApiProperty() @IsString() addressLine1: string;
  @ApiPropertyOptional() @IsOptional() @IsString() addressLine2?: string;
  @ApiProperty() @IsString() city: string;
  @ApiProperty() @IsString() state: string;
  @ApiProperty() @IsString() zipCode: string;
  @ApiPropertyOptional() @IsOptional() @IsString() country?: string;
  @ApiPropertyOptional() @IsOptional() @IsBoolean() isDefault?: boolean;
}

@ApiTags('users')
@ApiBearerAuth('access-token')
@UseGuards(JwtAuthGuard)
@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get('me')
  @ApiOperation({ summary: 'Get own profile' })
  getMe(@CurrentUser() user: User) { return this.usersService.findById(user.id); }

  @Put('me')
  @ApiOperation({ summary: 'Update profile' })
  updateMe(@CurrentUser() user: User, @Body() dto: UpdateProfileDto) {
    return this.usersService.updateProfile(user.id, dto);
  }

  @Patch('me/password')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Change password' })
  changePassword(@CurrentUser() user: User, @Body() dto: ChangePasswordDto) {
    return this.usersService.changePassword(user.id, dto.currentPassword, dto.newPassword);
  }

  @Delete('me')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Deactivate own account' })
  deactivate(@CurrentUser() user: User) {
    return this.usersService.deactivateAccount(user.id, user.id, user.role);
  }

  @Get('me/addresses')
  @ApiOperation({ summary: 'List saved addresses' })
  getAddresses(@CurrentUser() user: User) { return this.usersService.getAddresses(user.id); }

  @Post('me/addresses')
  @ApiOperation({ summary: 'Add address' })
  createAddress(@CurrentUser() user: User, @Body() dto: AddressDto) {
    return this.usersService.createAddress(user.id, dto);
  }

  @Put('me/addresses/:id')
  @ApiOperation({ summary: 'Update address' })
  updateAddress(@Param('id') id: string, @CurrentUser() user: User, @Body() dto: Partial<AddressDto>) {
    return this.usersService.updateAddress(id, user.id, dto);
  }

  @Patch('me/addresses/:id/default')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Set address as default' })
  setDefault(@Param('id') id: string, @CurrentUser() user: User) {
    return this.usersService.setDefaultAddress(id, user.id);
  }

  @Delete('me/addresses/:id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Delete address' })
  deleteAddress(@Param('id') id: string, @CurrentUser() user: User) {
    return this.usersService.deleteAddress(id, user.id);
  }

  @Get('me/wishlist')
  @ApiOperation({ summary: 'Get wishlist' })
  getWishlist(@CurrentUser() user: User, @Query('page') page = 1, @Query('limit') limit = 20) {
    return this.usersService.getWishlist(user.id, +page, +limit);
  }

  @Post('me/wishlist/:productId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Toggle product in wishlist' })
  toggleWishlist(@Param('productId') productId: string, @CurrentUser() user: User) {
    return this.usersService.toggleWishlist(user.id, productId);
  }

  @Delete('me/wishlist')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Clear wishlist' })
  clearWishlist(@CurrentUser() user: User) { return this.usersService.clearWishlist(user.id); }

  @Get()
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Admin: list users' })
  findAll(@Query('page') page = 1, @Query('limit') limit = 20, @Query('role') role?: UserRole, @Query('search') search?: string) {
    return this.usersService.findAll(+page, +limit, role, search);
  }

  @Get(':id')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Admin: get user by ID' })
  findOne(@Param('id') id: string) { return this.usersService.findById(id); }

  @Patch(':id')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Admin: update user role/status' })
  adminUpdate(@Param('id') id: string, @Body() body: { isActive?: boolean; isVerified?: boolean; role?: UserRole }) {
    return this.usersService.adminUpdateUser(id, body);
  }

  @Delete(':id')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Admin: delete user' })
  adminDelete(@Param('id') id: string) { return this.usersService.hardDelete(id); }
}

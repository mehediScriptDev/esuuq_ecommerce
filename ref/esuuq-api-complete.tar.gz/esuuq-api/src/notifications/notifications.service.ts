import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as sgMail from '@sendgrid/mail';
import * as admin from 'firebase-admin';

@Injectable()
export class NotificationsService {
  private readonly logger = new Logger(NotificationsService.name);
  private twilioClient: any;
  private firebaseReady = false;

  constructor(private readonly config: ConfigService) {
    // SendGrid
    sgMail.setApiKey(config.get<string>('SENDGRID_API_KEY', ''));

    // Twilio (lazy init)
    const sid   = config.get<string>('TWILIO_ACCOUNT_SID', '');
    const token = config.get<string>('TWILIO_AUTH_TOKEN', '');
    if (sid && token) {
      const twilio = require('twilio');
      this.twilioClient = twilio(sid, token);
    }

    // Firebase Admin
    const projectId    = config.get<string>('FIREBASE_PROJECT_ID', '');
    const clientEmail  = config.get<string>('FIREBASE_CLIENT_EMAIL', '');
    const privateKey   = config.get<string>('FIREBASE_PRIVATE_KEY', '').replace(/\\n/g, '\n');
    if (projectId && clientEmail && privateKey && !admin.apps.length) {
      admin.initializeApp({
        credential: admin.credential.cert({ projectId, clientEmail, privateKey }),
      });
      this.firebaseReady = true;
    }
  }

  // ── OTP ───────────────────────────────────────
  async sendOtpEmail(to: string, otp: string) {
    const from = this.config.get<string>('SENDGRID_FROM_EMAIL', 'noreply@esuuq.com');
    const fromName = this.config.get<string>('SENDGRID_FROM_NAME', 'ESUUQ');

    try {
      await sgMail.send({
        to,
        from: { email: from, name: fromName },
        subject: `Your ESUUQ verification code: ${otp}`,
        html: this.otpEmailHtml(otp),
      });
      this.logger.log(`OTP email sent to ${to}`);
    } catch (err) {
      this.logger.error(`Failed to send OTP email to ${to}:`, err.message);
    }
  }

  async sendOtpSms(phone: string, otp: string) {
    if (!this.twilioClient) return;
    try {
      await this.twilioClient.messages.create({
        body: `Your ESUUQ verification code is: ${otp}. Expires in 10 minutes.`,
        from: this.config.get<string>('TWILIO_FROM_NUMBER'),
        to: phone,
      });
      this.logger.log(`OTP SMS sent to ${phone}`);
    } catch (err) {
      this.logger.error(`Failed to send OTP SMS to ${phone}:`, err.message);
    }
  }

  // ── Order Notifications ───────────────────────
  async sendOrderConfirmation(
    to: string, orderId: string, total: number, otp: string,
  ) {
    const from = this.config.get<string>('SENDGRID_FROM_EMAIL', 'noreply@esuuq.com');
    try {
      await sgMail.send({
        to, from,
        subject: `Order Confirmed — ${orderId}`,
        html: this.orderConfirmHtml(orderId, total, otp),
      });
    } catch (err) {
      this.logger.error('Failed to send order confirmation:', err.message);
    }
  }

  async sendOrderStatusUpdate(
    to: string, orderId: string, newStatus: string,
  ) {
    const from = this.config.get<string>('SENDGRID_FROM_EMAIL', 'noreply@esuuq.com');
    try {
      await sgMail.send({
        to, from,
        subject: `Order ${orderId} — ${newStatus.replace(/_/g, ' ').toUpperCase()}`,
        html: `<p>Your order <strong>${orderId}</strong> is now <strong>${newStatus}</strong>.</p>`,
      });
    } catch (err) {
      this.logger.error('Failed to send status update:', err.message);
    }
  }

  // ── Push Notifications ────────────────────────
  async sendPush(fcmToken: string, title: string, body: string, data?: Record<string, string>) {
    if (!this.firebaseReady) return;
    try {
      await admin.messaging().send({
        token: fcmToken,
        notification: { title, body },
        data,
        android: { priority: 'high' },
        apns: { payload: { aps: { sound: 'default', badge: 1 } } },
      });
    } catch (err) {
      this.logger.error('Push notification failed:', err.message);
    }
  }

  async sendNewOrderToDriver(driverFcmToken: string, orderId: string, earnings: number) {
    await this.sendPush(
      driverFcmToken,
      '⚡ New Delivery Order',
      `Order #${orderId} — Earn $${earnings.toFixed(2)}`,
      { orderId, type: 'new_order' },
    );
  }

  async sendNewOrderToMerchant(merchantFcmToken: string, orderId: string) {
    await this.sendPush(
      merchantFcmToken,
      '📦 New Order Received',
      `Order ${orderId} needs your attention`,
      { orderId, type: 'new_order' },
    );
  }

  // ── Low Stock Alert ───────────────────────────
  async sendLowStockAlert(merchantId: string, product: { name: string; stock: number }) {
    this.logger.warn(`Low stock alert: "${product.name}" — ${product.stock} remaining [merchant: ${merchantId}]`);
    // TODO: look up merchant email and send
  }

  // ── Email Templates ───────────────────────────
  private otpEmailHtml(otp: string): string {
    return `
      <div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:2rem;background:#0A0F1E;color:#F8FAFC;border-radius:12px;">
        <div style="font-size:2rem;font-weight:800;margin-bottom:1rem;">ES<span style="color:#00C9A7">UUQ</span></div>
        <h2 style="margin-bottom:0.5rem;">Verify Your Account</h2>
        <p style="color:#94A3B8;margin-bottom:1.5rem;">Use the code below to verify your account. It expires in 10 minutes.</p>
        <div style="background:#1E2A3A;padding:1.5rem;border-radius:8px;text-align:center;letter-spacing:0.5em;font-size:2rem;font-weight:700;color:#00C9A7;margin-bottom:1.5rem;">${otp}</div>
        <p style="color:#94A3B8;font-size:0.8rem;">If you didn't request this, you can safely ignore this email.</p>
      </div>`;
  }

  private orderConfirmHtml(orderId: string, total: number, otp: string): string {
    return `
      <div style="font-family:sans-serif;max-width:520px;margin:0 auto;padding:2rem;">
        <div style="font-size:2rem;font-weight:800;margin-bottom:1rem;color:#0A0F1E;">ES<span style="color:#00C9A7">UUQ</span></div>
        <h2>Order Confirmed ✅</h2>
        <p>Your order <strong>${orderId}</strong> has been confirmed. Total: <strong>$${total}</strong></p>
        <p>Your delivery confirmation code (share with driver): <strong style="font-size:1.5rem;color:#00C9A7;">${otp}</strong></p>
        <p style="color:#666;font-size:0.8rem;">Keep this safe — you'll need it when the driver arrives.</p>
      </div>`;
  }
}

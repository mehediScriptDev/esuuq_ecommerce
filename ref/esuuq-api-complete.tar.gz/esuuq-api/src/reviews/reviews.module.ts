import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { ReviewsService } from './reviews.service';
import { ReviewsController } from './reviews.controller';
import { Review, ReviewHelpful } from '../database/entities/review-coupon.entities';
import { Product } from '../database/entities/product.entity';
import { Order, OrderItem } from '../database/entities/order.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Review, ReviewHelpful, Product, Order, OrderItem]),
  ],
  controllers: [ReviewsController],
  providers: [ReviewsService],
  exports: [ReviewsService],
})
export class ReviewsModule {}

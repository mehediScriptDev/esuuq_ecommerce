import {
  IsString, IsNumber, IsOptional, IsArray, IsEnum, IsUrl,
  Min, Max, MaxLength, MinLength,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { ReviewStatus } from '../../database/entities/review-coupon.entities';

// ─── Create ──────────────────────────────────────
export class CreateReviewDto {
  @ApiProperty({ example: 'prod_01HZ...' })
  @IsString()
  productId: string;

  @ApiProperty({ example: 'ESQ-2026-00847' })
  @IsString()
  orderId: string;

  @ApiProperty({ minimum: 1, maximum: 5, example: 5 })
  @IsNumber() @Min(1) @Max(5)
  rating: number;

  @ApiPropertyOptional({ example: 'Absolutely love these earbuds!' })
  @IsOptional() @IsString() @MaxLength(120)
  title?: string;

  @ApiPropertyOptional({ example: 'Great sound quality, comfortable fit, fast delivery.' })
  @IsOptional() @IsString() @MinLength(10) @MaxLength(2000)
  comment?: string;

  @ApiPropertyOptional({ type: [String], description: 'S3 image URLs (max 5)' })
  @IsOptional() @IsArray() @IsString({ each: true })
  images?: string[];
}

// ─── Update ──────────────────────────────────────
export class UpdateReviewDto {
  @ApiPropertyOptional()
  @IsOptional() @IsNumber() @Min(1) @Max(5)
  rating?: number;

  @ApiPropertyOptional()
  @IsOptional() @IsString() @MaxLength(120)
  title?: string;

  @ApiPropertyOptional()
  @IsOptional() @IsString() @MinLength(10) @MaxLength(2000)
  comment?: string;

  @ApiPropertyOptional({ type: [String] })
  @IsOptional() @IsArray() @IsString({ each: true })
  images?: string[];
}

// ─── Merchant Reply ───────────────────────────────
export class MerchantReplyDto {
  @ApiProperty({ example: 'Thank you so much for the kind words!' })
  @IsString() @MinLength(5) @MaxLength(1000)
  reply: string;
}

// ─── Moderation ───────────────────────────────────
export class ModerateReviewDto {
  @ApiProperty({ enum: ReviewStatus })
  @IsEnum(ReviewStatus)
  status: ReviewStatus;
}

// ─── Query ────────────────────────────────────────
export class ReviewQueryDto {
  @ApiPropertyOptional({ default: 1 })
  @IsOptional() @Type(() => Number) @IsNumber() @Min(1)
  page?: number = 1;

  @ApiPropertyOptional({ default: 10 })
  @IsOptional() @Type(() => Number) @IsNumber() @Min(1) @Max(50)
  limit?: number = 10;

  @ApiPropertyOptional({ minimum: 1, maximum: 5 })
  @IsOptional() @Type(() => Number) @IsNumber() @Min(1) @Max(5)
  rating?: number;

  @ApiPropertyOptional({ enum: ['newest', 'oldest', 'highest', 'lowest', 'helpful'] })
  @IsOptional() @IsString()
  sort?: string = 'newest';

  @ApiPropertyOptional()
  @IsOptional()
  verified?: boolean;
}
